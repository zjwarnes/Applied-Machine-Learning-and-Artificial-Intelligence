from sklearn import linear_model

import numpy as np

# load data: data loaded when .py file is in same directory as the .npy files
print('Loading data...')

X_train = np.load('tinyX.npy')
print('X_train shape is: ', X_train.shape)
print('X_train shape is: ', X_train.dtype)
X_train = X_train.flatten().reshape(26344, 3*64*64)
print('X_train shape is: ', X_train.shape)
print('X_train shape is: ', X_train.dtype)


Y_train = np.load('tinyY.npy')
print('Y_train shape is: ', Y_train.shape)
print('Y_train shape is: ', Y_train.dtype)
Y_train = Y_train.flatten()
print('Y_train shape is: ', Y_train.shape)
print('Y_train shape is: ', Y_train.dtype)


X_test = np.load('tinyX_test.npy')
print('X_test shape is: ', X_test.shape)
print('X_test shape is: ', X_test.dtype)
X_test = X_test.flatten().reshape(6600, 3*64*64)
print('X_test shape is: ', X_test.shape)
print('X_test shape is: ', X_test.dtype)

print('')

# convert the inputs, which are integers, to floats
# then, normalize the inputs, which are RGB ranging from 0-255, to 0-1
print('Normalizing input data...')
X_train = X_train.astype('float32')
X_train = X_train / 255.0
print('X_train shape is: ', X_train.shape)
print('X_train shape is: ', X_train.dtype)

X_test = X_test.astype('float32')
X_test = X_test / 255.0
print('X_test shape is: ', X_test.shape)
print('X_test shape is: ', X_test.dtype)

print('')

# visualizing
print(X_train[1])
print('=========')
print(X_train[1].transpose())
print('=========')

# create the model
print('Creating model...')
model = linear_model.LogisticRegression()

print('Fitting...')
model.fit(X_train, Y_train)

print('LogisticRegression score* %f' % model.score()))

print('Predicting...')
predict = model.predict(X_test)

print(predict)

print('Finished prediction. Need to create the .csv file.')


# creating the output file
file = open("results.csv","w") 

file.write("id,class\n")

for i in range(len(predict)):
	file.write(str(i)+","+str(predict[i])+"\n")
file.close() 

print('.csv file created.')
print('END')

