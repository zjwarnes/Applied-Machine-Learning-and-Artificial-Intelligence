import numpy as np

from keras.models import Sequential

from keras.layers import Dense
from keras.layers import Dropout
from keras.layers import Flatten

from keras.constraints import maxnorm
from keras.optimizers import SGD

from keras.layers.convolutional import Convolution2D
from keras.layers.convolutional import MaxPooling2D

from keras.utils import np_utils

from keras import backend as K
K.set_image_dim_ordering('th')

# load data: data loaded when .py file is in same directory as the .npy files
print('Loading data...')

X_train = np.load('tinyX.npy')
print('X_train shape is: ', X_train.shape)
print('X_train shape is: ', X_train.dtype)
# no need ##X_train = X_train.flatten().reshape(26344, 3*64*64)
print('X_train shape is: ', X_train.shape)
print('X_train shape is: ', X_train.dtype)


Y_train = np.load('tinyY.npy')
print('Y_train shape is: ', Y_train.shape)
print('Y_train shape is: ', Y_train.dtype)
# no need ##Y_train = Y_train.flatten()
print('Y_train shape is: ', Y_train.shape)
print('Y_train shape is: ', Y_train.dtype)

#convert the training output into a 40-col matrix
Y_train = np_utils.to_categorical(Y_train)
number_classes = Y_train.shape[1]

X_test = np.load('tinyX_test.npy')
print('X_test shape is: ', X_test.shape)
print('X_test shape is: ', X_test.dtype)
# no need ##X_test = X_test.flatten().reshape(6600, 3*64*64)
print('X_test shape is: ', X_test.shape)
print('X_test shape is: ', X_test.dtype)

print('')

# convert the inputs, which are integers, to floats
# then, normalize the inputs, which are RGB ranging from 0-255, to 0-1
print('Normalizing input data...')
X_train = X_train.astype('float32')
X_train = X_train / 255.0
print('X_train shape is: ', X_train.shape)
print('X_train shape is: ', X_train.dtype)

X_test = X_test.astype('float32')
X_test = X_test / 255.0
print('X_test shape is: ', X_test.shape)
print('X_test shape is: ', X_test.dtype)

print('')

# visualizing
print(X_train[1])
print('=========')
print(X_train[1].transpose())
print('=========')

# create model
# add dropoout throughout to reduce overfitting
print('Creating model...')
model = Sequential()

# filters = neurons
model.add(Convolution2D(64, 3, 3, input_shape=(3, 64, 64), border_mode='same', activation='relu', W_constraint=maxnorm(3)))
model.add(Dropout(0.2))

model.add(Convolution2D(64, 3, 3, activation='relu', border_mode='same', W_constraint=maxnorm(3)))

model.add(MaxPooling2D(pool_size=(2, 2)))       # generalize the feature maps generated from the previous 2 convolutions

model.add(Flatten())

# 2 hidden layers, 32 neurons each, due to limitations
model.add(Dense(32, activation='relu', W_constraint=maxnorm(3)))
model.add(Dropout(0.2))

model.add(Dense(32, activation='relu', W_constraint=maxnorm(3)))
model.add(Dropout(0.2))

# output layer
model.add(Dense(number_classes, activation='softmax'))

# compile model
# initialize variables for SGD
learning_rate = 0.01    # arbitrary
epochs = 10             # due to time constraints
decay = learning_rate/epochs    

sgd = SGD(lr=learning_rate, momentum=0.9, decay=decay, nesterov=False)  # stochastic gradient descent

model.compile(loss='categorical_crossentropy', optimizer=sgd, metrics=['accuracy'])

# print summary
print(model.summary())

# fit model
print('Fitting...')
model.fit(X_train, Y_train, nb_epoch=epochs, batch_size=100, verbose=2) # update every 100 images

# predict
print('Predicting...')
predict = model.predict(X_test)

# print prediction
print(predict)

print('Finished prediction. Need to create the .csv file.')


# creating the output file
# predict 40-col arrays data
file = open("results.csv","w") 
file.write("id,class\n")

for i in range(len(predict)):
	file.write(str(i) + "," + str(predict[i]) + "\n")
file.close() 

print('.csv file created.')
print('END')

# prediction class data
file2 = open("results2.csv", "w")       # submit this file
file2.write("id,class\n")

for i in range(len(predict)):
	file2.write(str(i) + "," + str(predict[i].argmax(axis=0)) + "\n")     # finds index of the max element in array
file.close() 

print('.csv file created.')
print('END')
# END #################

"""
Creating model...
____________________________________________________________________________________________________
Layer (type)                     Output Shape          Param #     Connected to                     
====================================================================================================
convolution2d_1 (Convolution2D)  (None, 64, 64, 64)    1792        convolution2d_input_1[0][0]      
____________________________________________________________________________________________________
dropout_1 (Dropout)              (None, 64, 64, 64)    0           convolution2d_1[0][0]            
____________________________________________________________________________________________________
convolution2d_2 (Convolution2D)  (None, 64, 64, 64)    36928       dropout_1[0][0]                  
____________________________________________________________________________________________________
maxpooling2d_1 (MaxPooling2D)    (None, 64, 32, 32)    0           convolution2d_2[0][0]            
____________________________________________________________________________________________________
flatten_1 (Flatten)              (None, 65536)         0           maxpooling2d_1[0][0]             
____________________________________________________________________________________________________
dense_1 (Dense)                  (None, 32)            2097184     flatten_1[0][0]                  
____________________________________________________________________________________________________
dropout_2 (Dropout)              (None, 32)            0           dense_1[0][0]                    
____________________________________________________________________________________________________
dense_2 (Dense)                  (None, 32)            1056        dropout_2[0][0]                  
____________________________________________________________________________________________________
dropout_3 (Dropout)              (None, 32)            0           dense_2[0][0]                    
____________________________________________________________________________________________________
dense_3 (Dense)                  (None, 40)            1320        dropout_3[0][0]                  
====================================================================================================
Total params: 2,138,280
Trainable params: 2,138,280
Non-trainable params: 0
____________________________________________________________________________________________________
None
Fitting...
Epoch 1/10
2242s - loss: 2.7720 - acc: 0.2960
Epoch 2/10
2216s - loss: 2.5580 - acc: 0.3096
Epoch 3/10
2181s - loss: 2.4326 - acc: 0.3250
Epoch 4/10
2251s - loss: 2.3415 - acc: 0.3431
Epoch 5/10
2493s - loss: 2.2678 - acc: 0.3635
Epoch 6/10
2315s - loss: 2.1999 - acc: 0.3790
Epoch 7/10
2214s - loss: 2.1390 - acc: 0.3948
Epoch 8/10
2151s - loss: 2.0834 - acc: 0.4120
Epoch 9/10
2137s - loss: 2.0413 - acc: 0.4226
Epoch 10/10
2147s - loss: 2.0020 - acc: 0.4320
Predicting...
[[  3.55215035e-02   6.14856221e-02   8.98103833e-01 ...,   7.55071255e-07
    4.65023149e-05   2.45373172e-07]
 [  9.87202108e-01   6.42531645e-03   2.71620019e-03 ...,   2.95415873e-07
    7.78462709e-05   3.97534379e-08]
 [  5.32893538e-01   6.80622235e-02   3.55394669e-02 ...,   2.35712412e-03
    9.94349737e-03   1.40022661e-03]
 ..., 
 [  5.37604839e-02   3.39480788e-02   1.61374491e-02 ...,   1.46128852e-02
    1.89531893e-02   2.97342502e-02]
 [  9.88699734e-01   8.60538706e-03   1.18660252e-03 ...,   1.58564912e-08
    1.75892637e-05   4.92783014e-09]
 [  2.13397015e-02   5.56512363e-03   9.88388201e-04 ...,   1.07466631e-01
    2.39102263e-03   6.65209861e-03]]
Finished prediction. Need to create the .csv file.
.csv file created.
END
.csv file created.
END
"""
