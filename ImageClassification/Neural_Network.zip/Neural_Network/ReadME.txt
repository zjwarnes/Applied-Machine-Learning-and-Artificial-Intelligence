The NeuralNetwork File is composed of 4 files.

convert_gray.py converts the images to grayscale (Assumes the data is in same folder) and outputs the gray dataset.

neural_net_gray.py reads the gray dataset, and performs the neural network weight updates. The script outputs the weights to the model.

output_gray.py reads the model weights and performs classification on the grey test data. 

sk_learn.py contains the sk_learn implementation of neural networks to find the optimal parameters. 

