from __future__ import division
from cmath import sqrt
# from sklearn.cross_validation import cross_val_score

import pandas
import numpy as np
np.set_printoptions(threshold=np.nan)
import random
import math
import re, string

def softmax(x):
    return np.exp(x) / np.sum(np.exp(x), axis=0)
	
	
trainX = np.load('tinyX.npy') # this should have shape (26344, 3, 64, 64)
trainY = np.load('tinyY.npy') 
testX = np.load('tinyX_test.npy') # (6600, 3, 64, 64)


class_count = 40
sample_count = 26344
test_count = 6600
gray_pixel_count = 64*64


trainY_results = np.zeros((sample_count,class_count))
for i in range(sample_count):
	trainY_results[i,trainY[i]]=1
np.save('trainY_flat.npy', trainY_results)	

# Greyscale
trainX_g = np.zeros([64,64,sample_count])
for i in range(sample_count):
	print("Grey Train : ",i)
	for j in range(64):
		for k in range(64):
		#GrayScale Formula
			trainX_g[j,k,i]=0.2989 * trainX[i][0,j,k] + 0.5870 * trainX[i][1,j,k] + 0.1140 * trainX[i][2,j,k]

#Flatten 2D to 1D
trainX_f = np.ones((sample_count,gray_pixel_count+1))

for i in range(sample_count):
	print("Grey Train Flat : ",i)
	y = trainX_g[:,:,i]
	y = y.flatten()
	#Normalize
	trainX_f[i,0:gray_pixel_count]=y/255

# np.savetxt('Gray_flat_train.csv', trainX_f, delimiter=',')
np.save('Gray_flat_train.npy', trainX_f)

# Greyscale
testX_g = np.zeros([64,64,test_count])
for i in range(test_count):
	print("Grey Test : ",i)
	for j in range(64):
		for k in range(64):
			testX_g[j,k,i]=0.2989 * testX[i][0,j,k] + 0.5870 * testX[i][1,j,k] + 0.1140 * testX[i][2,j,k]

testX_f = np.ones((test_count,gray_pixel_count+1))
for i in range(test_count):
	print("Grey Test Flat : ",i)
	y = testX_g[:,:,i]
	y = y.flatten()
	testX_f[i,0:gray_pixel_count]=y/255

# np.savetxt('Gray_flat_test.csv', testX_f, delimiter=',')
np.save('Gray_flat_test.npy', testX_f)


