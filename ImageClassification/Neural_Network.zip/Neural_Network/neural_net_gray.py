from __future__ import division
from cmath import sqrt
# from sklearn.cross_validation import cross_val_score

import pandas
import numpy as np
np.set_printoptions(threshold=np.nan)
import random
import math
import re, string
##########################################
## HyperParameters
# Number of hidden layers and Nodes
# learning rate
# momentum
##########################################
def softmax(x):
    return np.exp(x) / np.sum(np.exp(x), axis=0)
	
	
trainX = np.load('tinyX.npy') # this should have shape (26344, 3, 64, 64)
trainY = np.load('tinyY.npy') 
testX = np.load('tinyX_test.npy') # (6600, 3, 64, 64)

sample_count = 26344
class_count = 40
grey_size = 64*64+1;



trainY_results=np.load('trainY_flat.npy')
print(trainY_results.shape)
gray_train = np.load('gray_flat_train.npy')
print(gray_train.shape)
gray_test = np.load('gray_flat_test.npy')
print(gray_test.shape)



#Shuffle the Input and Outputs
training_set_index = np.arange(sample_count)
np.random.shuffle(training_set_index)

gray_train2= np.zeros((sample_count,64*64+1))
trainY_results2 = np.zeros((sample_count,40))
for i in range(sample_count):
	shuffle_i = training_set_index[i]
	gray_train2[i,:]=gray_train[shuffle_i]
	trainY_results2[i,:]=trainY_results[shuffle_i]

#Training And Validation
validation_size=500
training_size = sample_count-validation_size
gray_valid = gray_train2[training_size:sample_count,:]
trainY_valid = trainY_results2[training_size:sample_count,:]	


## Neural Network
total_epoch_error=100
max_epoch=3
epoch_results = np.zeros((max_epoch,3))
alpha = 0.01
#Random Value Weights
hl_weights=np.random.random((40,grey_size))/100



for epoch in range(max_epoch):
	total_error=0
	for sample_index in range(training_size):
		sig1 = np.zeros(40)
		output = np.ones(40)
		#
		for i in range(40):
			output[i] = 1/(1+np.exp(-np.dot(gray_train2[sample_index,:],hl_weights[i,:])))

		output = softmax(output)
		error=0
		for i in range(class_count):
			error=error+0.5*((trainY_results2[sample_index,i]-output[i])**2)
		# print(error)
		total_error=total_error+error
		
		#Weight Update
		for j in range(40):
			sig1[j]=-1*(trainY_results2[sample_index,j]-output[j])*output[j]*(1-output[j])
			for i in range(grey_size):
				hl_weights[j,i] = hl_weights[j,i]-alpha*sig1[j]*gray_train2[sample_index,i]		


		if(sample_index%500==0):
			print("At Index: ", sample_index," and epoch: ", epoch)
		

	
	validation_error = 0
	correct_predictions=0
	for sample_index in range(validation_size):

		output = np.ones(40)
		
		for i in range(40):
			output[i] = 1/(1+np.exp(-np.dot(gray_valid[sample_index,:],hl_weights[i,:])))
					
					
		output = softmax(output)
		if np.isnan(np.max(output))==1:
			print("Big Problem")
		
		error=0
		for i in range(class_count):
			error=error+0.5*((trainY_valid[sample_index,i]-output[i])**2)	
		validation_error = validation_error + error
		
		if output.argmax(axis=0) == trainY_valid[i,:].argmax(axis=0):
			correct_predictions = correct_predictions+1
			
	print("Correct Predictions: ", correct_predictions)		
	print("Accuracy: ", correct_predictions/validation_size)		
	epoch_results[epoch,:]=[epoch,total_error,validation_error]	
	np.save('Weights.npy', hl_weights)	
	print("Epoch Count: ", epoch, " with error ", total_error, " and validation error", validation_error)
	if total_error<total_epoch_error:
		break


	
	
	
###
## Show Image
###
# index=10000
# from matplotlib import pyplot as plt
# plt.imshow(trainX[index].transpose(2,1,0))
# plt.show()
# print(trainY[index])