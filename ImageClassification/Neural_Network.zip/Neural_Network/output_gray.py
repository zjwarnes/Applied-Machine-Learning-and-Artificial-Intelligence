from __future__ import division
from cmath import sqrt
# from sklearn.cross_validation import cross_val_score

import pandas
import numpy as np
np.set_printoptions(threshold=np.nan)
import random
import math
import re, string

def softmax(x):
    return np.exp(x) / np.sum(np.exp(x), axis=0)
	
	
sample_count = 26344
counts = np.zeros(40)	
trainY = np.load('tinyY.npy')
for i in range(sample_count):
	counts[trainY[i]]=counts[trainY[i]]+1

print(counts)

weights=np.load('Weights.npy')

gray_test = np.load('gray_flat_test.npy')
print(gray_test.shape)
test_count = 6600

results=np.zeros((test_count,2))
results[:,0]=np.arange(test_count)

for test_index in range(test_count):
	output = np.ones(40)

	for i in range(40):
		output[i] = 1/(1+np.exp(-np.dot(gray_test[test_index,:],weights[i,:])))
	
	output = softmax(output)
	results[test_index,1]=output.argmax(axis=0)
		
np.savetxt('output_results.csv', results, delimiter=',')