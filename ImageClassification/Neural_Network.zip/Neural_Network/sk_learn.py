from sklearn.neural_network import MLPClassifier

import pandas
import numpy as np
np.set_printoptions(threshold=np.nan)
import random
import math
import re, string

trainX = np.load('tinyX.npy') # this should have shape (26344, 3, 64, 64)
trainY = np.load('tinyY.npy') 
testX = np.load('tinyX_test.npy') # (6600, 3, 64, 64)

sample_count = 26344
class_count = 40
test_count = 6600
X=[]
X_test=[]
X_val=[]
Y_val=[]
y=[]
	

trainY_results=np.load('trainY_flat.npy')
print(trainY_results.shape)
gray_train = np.load('gray_flat_train.npy')
print(gray_train.shape)
# gray_test = np.load('gray_flat_test.npy')
# print(gray_test.shape)
# for i in range(test_count):
	# X_test.append(gray_test[i,:])


#Shuffle the Input and Outputs
training_set_index = np.arange(sample_count)
np.random.shuffle(training_set_index)

gray_train2= np.zeros((sample_count,64*64+1))
trainY_results2 = np.zeros((sample_count,40))
for i in range(sample_count):
	shuffle_i = training_set_index[i]
	gray_train2[i,:]=gray_train[shuffle_i]
	trainY_results2[i,:]=trainY_results[shuffle_i]
	
#Training And Validation
validation_size=500
training_size = sample_count-validation_size
gray_valid = gray_train2[training_size:sample_count,:]
trainY_valid = trainY_results2[training_size:sample_count,:]

for i in range(training_size):
	X.append(gray_train2[i,:])
	y.append(trainY_results2[i,:])

for i in range(validation_size):
	X_val.append(gray_valid[i,:])
	Y_val.append(trainY_valid[i,:])
	
learning_rates= [0.001,0.01,0.1]
max_iter = [3,5,10]
hidden_layer_nodes = [400,50,10]
results = np.zeros(36)
counter= 0
# for i in range(3):
	# for j in range(3):
		# clf = MLPClassifier(solver='sgd', activation='logistic', alpha=1e-5, learning_rate_init=learning_rates[i], max_iter=max_iter[j], random_state=1)
		# clf.fit(X, y)                         

		# predictions = clf.predict_proba(X_val[:])
		# correct_predictions = 0
		# for valid_sample in range(validation_size):
			# # print("Prediction: ", predictions[i].argmax(axis=0), ". Actual Class: ", trainY_valid[i,:].argmax(axis=0))
			# if predictions[valid_sample,:].argmax(axis=0) == trainY_valid[valid_sample,:].argmax(axis=0):
				# correct_predictions = correct_predictions+1
				# # print("Prediction: ", predictions[i,:].argmax(axis=0), ". Actual Class: ", trainY_valid[i,:].argmax(axis=0))
		# results[counter]=correct_predictions/validation_size
		# print("Validation Accuracy: ", results[counter])	
		# counter=counter+1

# for i in range(3):
	# for j in range(3):
		# for k in range(3):
			# clf = MLPClassifier(solver='sgd', activation='logistic', hidden_layer_sizes=(hidden_layer_nodes[k], ), alpha=1e-5, learning_rate_init=learning_rates[i], max_iter=max_iter[j], random_state=1)
			# clf.fit(X, y)                         

			# predictions = clf.predict_proba(X_val[:])
			# correct_predictions = 0
			# for valid_sample in range(validation_size):
				# # print("Prediction: ", predictions[i].argmax(axis=0), ". Actual Class: ", trainY_valid[i,:].argmax(axis=0))
				# if predictions[valid_sample,:].argmax(axis=0) == trainY_valid[valid_sample,:].argmax(axis=0):
					# correct_predictions = correct_predictions+1
					# # print("Prediction: ", predictions[i,:].argmax(axis=0), ". Actual Class: ", trainY_valid[i,:].argmax(axis=0))
			# results[counter]=correct_predictions/validation_size
			# print("Validation Accuracy: ", results[counter])
			# counter=counter+1

for i in range(3):
	for j in range(3):
		for k in range(3):
			for l in range(3):
				clf = MLPClassifier(solver='sgd', activation='logistic', hidden_layer_sizes=(hidden_layer_nodes[k],hidden_layer_nodes[l] ), alpha=1e-5, learning_rate_init=learning_rates[i], max_iter=max_iter[j], random_state=1)
				clf.fit(X, y)                         

				predictions = clf.predict_proba(X_val[:])
				print(predictions.shape)
				correct_predictions = 0
				for valid_size in range(validation_size):
					# print("Prediction: ", predictions[i].argmax(axis=0), ". Actual Class: ", trainY_valid[i,:].argmax(axis=0))
					if predictions[valid_size,:].argmax(axis=0) == trainY_valid[valid_size,:].argmax(axis=0):
						correct_predictions = correct_predictions+1
						# print("Prediction: ", predictions[i,:].argmax(axis=0), ". Actual Class: ", trainY_valid[i,:].argmax(axis=0))
				results[counter]=correct_predictions/validation_size
				print("Validation Accuracy: ", results[counter])
				counter=counter+1
print(results)
np.save('validation_results_dual.npy',results)