To run SVM.py:

make sure tinyX.npy, tinyX_test.npy, and tinyY.npy are all in the folder running SVM.py
simply load the code and run

this should run a SVM classifier on 1/8th of the training data
using various combinations of kernels, grayscaling and feature extraction.