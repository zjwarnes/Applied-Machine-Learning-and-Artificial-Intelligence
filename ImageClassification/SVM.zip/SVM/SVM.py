import numpy as np
import cv2 as cv
import scipy.misc as scm
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score

def loadData():
    trainX = np.load('tinyX.npy') # this should have shape (26344, 3, 64, 64)
    trainY = np.load('tinyY.npy') 
    testX = np.load('tinyX_test.npy') # (6600, 3, 64, 64)        
    return [trainX, trainY, testX]

def compressByLightness(imageData, num_images):
    #max(R,G,B) + min(R,G,B) /2
    print 'Lightness Grayscale'
    grayImages = (np.max(imageData, axis =1) + np.min(imageData, axis = 1))/2
    grayImages = np.reshape(grayImages, (num_images, 4096))
    print 'check shape'
    print np.shape(grayImages)
    return grayImages

def compressByAverage(imageData, num_images):
    #(R, G, B)/3
    print 'Average Grayscale'
    grayImages = np.average(imageData, axis =1)
    grayImages = np.reshape(grayImages, (num_images, 4096))
    print 'check shape'
    print np.shape(grayImages)
    return grayImages

def compressByLuminosity(imageData, num_images):
    # 0.21R + 0.72G + 0.07B
    print 'Luminosity Grayscale'
    grayImages = 0.21*imageData[:,0,:,:]+0.72*imageData[:,1,:,:]+0.07*imageData[:,2,:,:]
    grayImages = np.reshape(grayImages, (num_images, 4096))
    print 'check shape'
    print np.shape(grayImages)
    return grayImages

#shuffles X and Y while maintaining matching
def shuffleXandY(X,y):
    totMatrix = np.hstack((X,y))
    np.random.shuffle(totMatrix)
    sze = np.size(X, axis =1)
    #returns X and y, now shuffled
    return [totMatrix[:,0:sze],totMatrix[:,sze:sze+1]]
    
def svm(C_Penalty, Kernel, PolyKer_Deg, Gamma, tol, random_state, fraction, threshold = 500, compressionType = 'average', surf = False):
    [X_train, y_train, X_test] = loadData()
    #add dimension to y, for shuffling
    y_train = np.reshape(y_train, (np.size(y_train),1))
    
    #whether or not to use surf feature extraction    
    if surf == True:
        X_train = loadSurfFeatures(X_train, np.size(X_train, axis=0), compressionType, threshold)
    #determine which gray scaling to use
    elif compressionType == 'average':
        X_train = compressByAverage(X_train, np.size(X_train, axis =0))
        X_test = compressByAverage(X_test, np.size(X_test, axis =0))
    elif compressionType == 'lightness':
        X_train = compressByLightness(X_train, np.size(X_train, axis =0))
        X_test = compressByLightness(X_test, np.size(X_test, axis =0))
    elif compressionType == 'luminosity':
        X_train = compressByLuminosity(X_train, np.size(X_train, axis =0))
        X_test = compressByLuminosity(X_test, np.size(X_test, axis =0))
        
        
    [X_train, y_train] = shuffleXandY(X_train, y_train)
    y_train = np.reshape(y_train, (np.size(y_train),))
    
    #take a portion of the data, depending on fraction
    X_train = X_train[0:np.size(X_train, axis =0)/fraction,:]
    y_train = y_train[0:np.size(y_train, axis =0)/fraction]
    
    #set up and train classifier using one vs all
    clf = SVC(decision_function_shape='ovo', kernel= Kernel, C=C_Penalty, degree=PolyKer_Deg, gamma=Gamma, tol=tol, random_state=random_state)
    clf = clf.fit(X_train,y_train)
    
    #calculate accuracy using a 5 fold cross validation split
    scores = cross_val_score(estimator=clf, X = X_train, y = y_train, cv = 5)
    print scores
    

#to be used after original load
def loadSurfFeatures(imageData, numImages, grayScaleType = 'average', Threshold = 300):
    
    #determine which gray scale to use
    if grayScaleType == 'lightness':
        grayImages = (np.max(imageData, axis =1) + np.min(imageData, axis = 1))/2
    elif grayScaleType == 'luminosity':
        grayImages = 0.21*imageData[:,0,:,:]+0.72*imageData[:,1,:,:]+0.07*imageData[:,2,:,:]
    elif grayScaleType == 'average':
        grayImages = np.average(imageData, axis =1)
        
    #each image is now in grayscale
    grayImages = np.reshape(grayImages, (numImages, 64,64))
    
    #init useful variables
    XTrain= np.zeros((numImages,32,64))
    maxKp = 0
    maxi = 0
    for i in range(1,numImages+1):
        #convert numpy arrays to png images to use in surf
        scm.imsave('Images_PNG\Image'+str(i)+'.png', grayImages[i-1])

        #determine key points of a particular image
        newimage = cv.imread('Images_PNG\Image'+str(i)+'.png',0)
        
        #threshold determines the number of key points
        surf = cv.SURF(Threshold)
        
        #upright creates orientation for each key point
        surf.upright = True
        
        #limits one dimension of matrix to 64
        surf.extended = False
        
        #return the key points and the description of them
        kp, des = surf.detectAndCompute(newimage, None)    
        
        #track image with most key points
        if len(kp) > maxKp:
            maxKp = len(kp)
            maxi = i
        if len(kp) == 0:
            continue
        
        #load feature extraction description into training array
        XTrain[i-1,0:np.size(des,axis=0)] = des
        
    #debugging incase dimensions of numpy array need to be modified
    print 'Maximum keypoints'+ str(maxKp) + ' at i = ' + str(maxi)

    #reshape into 2D array for training
    XTrain = np.reshape(XTrain, (numImages, 2048))
    return XTrain


# inputs are penalty, kernel, polynomial degree, tolerance
# randomstate, fraction of input data (for reduced computation), grayscale compression type, and whether or not to use surf
#grayscale types are 'average', 'luminosity', and 'lightness'

#if using surf, create a folder called Images_PNG this is used when converting numpy arrays to png to use surf
#also the code assumes windows OS, if using Mac or linux change '\' to '/' in the loadsurffeatures method


#The follow code run combinations of different gray scales and kernels 
#with and without SRUF of 1/8 of the training data
 
grays = ['average','luminosity','lightness']
kernels = ['rbf', 'poly']

for g in grays:
    for k in kernels:
        print 'Scaling: ' + g + '   Kernel ' + k
        svm(1,k,3,'auto',tol=1e-4,random_state=42,fraction=8, compressionType=g, surf=False)

print '\n Now using surf'
for g in grays:
    for k in kernels:
        print 'Scaling: ' + g + '   Kernel ' + k
        svm(1,k,3,'auto',tol=1e-4,random_state=42,fraction=8, compressionType=g, surf=True)


